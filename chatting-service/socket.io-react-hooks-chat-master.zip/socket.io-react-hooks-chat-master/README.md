Read more about the app: [Build a real-time chat app with React hooks and Socket.io](https://medium.com/p/build-a-real-time-chat-app-with-react-hooks-and-socket-io-4859c9afecb0?source=email-63d38b10a2f2--writer.postDistributed&sk=033d9c474a542bd8640709295b842729).

Live demo: https://socket-io-react-hooks-chat.herokuapp.com/
